import 'package:flutter/material.dart';


class LockerPage extends StatelessWidget {
  final String shipperPhone;
  const LockerPage({super.key, required this.shipperPhone});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Text("Locker Page\nShipper: $shipperPhone"),
      ),
    );
  }
}

