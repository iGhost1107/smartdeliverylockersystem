import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:flutter_map_location_marker/flutter_map_location_marker.dart';
import 'package:flutter_polyline_points/flutter_polyline_points.dart';
import 'package:latlong2/latlong.dart';
import 'package:location/location.dart';
import 'package:http/http.dart' as http;

class OpenstreetmapScreen extends StatefulWidget {
  const OpenstreetmapScreen({super.key});

  @override
  State<OpenstreetmapScreen> createState() => _OpenstreetmapScreenState();
}

class _OpenstreetmapScreenState extends State<OpenstreetmapScreen> {
  final MapController _mapController = MapController();
  final Location _location = Location();
  final TextEditingController _markerInputController = TextEditingController();
  final TextEditingController _locationController = TextEditingController();
  bool isLoading =true;
  LatLng? _currentLocation;
  LatLng? _destination;
  List<LatLng> _route = [];
  List<Marker> _customMarkers = [];


  void initState() {
    super.initState();
    _initializationLocation();
  }

  @override
  void dispose() {
    _locationController.dispose();
    _markerInputController.dispose();
    super.dispose();
  }

  Future<void> _initializationLocation() async {
    if(!await _checktheRequestPermissions()) return;


    _location.onLocationChanged.listen((LocationData locationData) {
      if(locationData.latitude != null && locationData.longitude != null) {
        setState(() {
          _currentLocation = LatLng(locationData.latitude!, locationData.longitude!);
          isLoading = false;
        });
      }
    });
  }


  // Method to fetch coordinates for a given location using the OpenStreetMap Nominatim API.
  Future<void> _fetchCoordinatesPoints(String location) async {
    // Construct the API URL with the given location.
    final url = Uri.parse(
        'https://nominatim.openstreetmap.org/search?q= $location&format=json&limit=1'
    );

    // Make an HTTP GET request to the API.
    final response = await http.get(url);

    // Check if the HTTP request was successful (status code 200).
    if (response.statusCode == 200) {
      // Decode the JSON response.
      final data = json.decode(response.body);

      // Check if the response contains any data.
      if (data.isNotEmpty) {
        // Extract latitude and longitude from the API response.
        final lat = double.parse(data[0]['lat']);
        final lon = double.parse(data[0]['lon']);

        // Update the state with the destination coordinates.
        setState(() {
          _destination = LatLng(lat, lon); // Set the destination coordinates.
        });

        // Fetch the route to the destination.
        await _fetchRoute();
      } else {
        // Display an error message if the location is not found.
        errorMessage('Location not found. Please try another search.');
      }
    } else {
      // Display an error message if the HTTP request failed.
      errorMessage('Failed to fetch location. Try again later.');
    }
  }

  void errorMessage(String message){
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message)
      ),
    );
  }

  // Method to fetch the route between the current location and the destination.
  Future<void> _fetchRoute() async {
    // Check if both current location and destination are not null.
    if (_currentLocation == null || _destination == null) return;

    // Construct the API URL with the current location and destination coordinates.
    final url = Uri.parse(
        'http://router.project-osrm.org/route/v1/driving/'
            '${_currentLocation!.longitude},${_currentLocation!.latitude};'
            '${_destination!.longitude},${_destination!.latitude}'
            '?overview=full&geometries=polyline'
    );

    // Make an HTTP GET request to the API.
    final response = await http.get(url);

    // Check if the HTTP request was successful (status code 200).
    if (response.statusCode == 200) {
      // Decode the JSON response.
      final data = json.decode(response.body);

      // Extract the geometry of the route from the API response.
      final geometry = data['routes'][0]['geometry'];

      // Decode the polyline into a list of coordinates.
      _decodePolyline(geometry); // Assuming _decodePolyline is defined elsewhere.
    } else {
      // Display an error message if the route fetch failed.
      errorMessage('Failed to fetch route. Try again later.');
    }
  }

  void _decodePolyline(String encodedPolyline) {
    // Create an instance of PolylinePoints for decoding the polyline.
    PolylinePoints polylinePoints = PolylinePoints();

    // Decode the encoded polyline into a list of PointLatLng objects.
    List<PointLatLng> decodedPoints =
    polylinePoints.decodePolyline(encodedPolyline);

    // Update the state with the decoded route coordinates.
    setState(() {
      _route = decodedPoints
          .map((point) => LatLng(point.latitude, point.longitude))
          .toList();
    });
  }

  Future<bool> _checktheRequestPermissions() async {
    bool serviceEnabled = await _location.serviceEnabled();
    if(!serviceEnabled) {
      serviceEnabled = await _location.requestService();
      if(!serviceEnabled) return false;
    }

    PermissionStatus permissionGranted = await _location.hasPermission();
    if(permissionGranted == PermissionStatus.denied) {
      permissionGranted = await _location.requestPermission();
      if (permissionGranted != PermissionStatus.granted) return false;
    }
    return true;
  }
  Future<void> _userCurrentLocation() async {
    if(_currentLocation != null) {
      _mapController.move(_currentLocation!, 15);
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
            content: Text("Current location not available")
        )
      );
    }
  }


  void _addCustomMarker(LatLng point, {String? label}) {
    final marker = Marker(
      width: 60,
      height: 60,
      point: point,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (label != null)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(6),
                boxShadow: [BoxShadow(blurRadius: 3, color: Colors.black26)],
              ),
              child: Text(
                label,
                style: const TextStyle(fontSize: 12, color: Colors.black),
                textAlign: TextAlign.center,
              ),
            ),
          const Icon(
            Icons.location_pin,
            color: Colors.purple,
            size: 36,
          ),
        ],
      ),
    );

    setState(() {
      _customMarkers.add(marker);
    });
  }

  void _handleCustomMarkerInput() {
    final input = _markerInputController.text.trim();

    // Expecting format: 'LatLng(21.0, 105.8), labelText'
    final regex = RegExp(r'LatLng\(([-\d.]+),\s*([-\d.]+)\)(?:,\s*(.*))?');
    final match = regex.firstMatch(input);

    if (match != null) {
      final lat = double.tryParse(match.group(1)!);
      final lng = double.tryParse(match.group(2)!);
      final label = match.group(3)?.trim();

      if (lat != null && lng != null) {
        final point = LatLng(lat, lng);
        _addCustomMarker(point, label: label?.isEmpty == true ? null : label);
      } else {
        errorMessage("Invalid coordinates format.");
      }
    } else {
      errorMessage("Input must be in format: LatLng(lat, lng), optionalLabel");
    }
  }



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        foregroundColor: Colors.white,
        title: const Text("Open Street Map"),
        backgroundColor: Colors.blue,
      ),
      body: Stack(
        children: [
          if (isLoading)
            const Center(child: CircularProgressIndicator())
          else
            FlutterMap(
              mapController: _mapController,
              options: MapOptions(
                initialCenter: _currentLocation ?? const LatLng(21.0278, 105.8342),
                initialZoom: 13,
                minZoom: 5,
                maxZoom: 18,
              ),
              children: [
                TileLayer(
                  urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                ),
                CurrentLocationLayer(
                  style: LocationMarkerStyle(
                    marker: DefaultLocationMarker(
                      child: Icon(
                        Icons.location_pin,
                        color: Colors.blue,
                        size: 30,
                      ),
                    ),
                    markerSize: Size(35, 35),
                    markerDirection: MarkerDirection.heading,
                  ),
                ),
                if (_customMarkers.isNotEmpty)
                  MarkerLayer(markers: _customMarkers),
                // Destination Marker Layer
                if (_destination != null)
                  MarkerLayer(
                    markers: [
                      Marker(
                        width: 80,
                        height: 80,
                        point: _destination!,
                        child: const Icon(
                          Icons.location_pin,
                          color: Colors.red,
                          size: 40,
                        ),
                      ),
                    ],
                  ),
                // Polyline Route Layer
                if (_route.isNotEmpty)
                  PolylineLayer(
                    polylines: [
                      Polyline(
                        points: _route,
                        strokeWidth: 5,
                        color: Colors.blue.withOpacity(0.7),
                      ),
                    ],
                  ),
              ],
            ),
          Positioned(
            top: 0,
            right: 0,
            left: 0,
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Column(
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: TextField(
                          controller: _locationController,
                          decoration: InputDecoration(
                            filled: true,
                            fillColor: Colors.white,
                            hintText: 'Enter a location',
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(30),
                              borderSide: BorderSide.none,
                            ),
                            contentPadding:
                            const EdgeInsets.symmetric(horizontal: 20),
                          ),
                        ),
                      ),
                      IconButton(
                        style: IconButton.styleFrom(backgroundColor: Colors.white),
                        onPressed: () {
                          final location = _locationController.text.trim();
                          if (location.isNotEmpty) {
                            _fetchCoordinatesPoints(location);
                          }
                        },
                        icon: const Icon(Icons.search),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      Expanded(
                        child: TextField(
                          controller: _markerInputController,
                          decoration: InputDecoration(
                            filled: true,
                            fillColor: Colors.white,
                            hintText: 'e.g. LatLng(21.0, 105.8), Shop Label',
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(30),
                              borderSide: BorderSide.none,
                            ),
                            contentPadding:
                            const EdgeInsets.symmetric(horizontal: 20),
                          ),
                        ),
                      ),
                      IconButton(
                        style: IconButton.styleFrom(backgroundColor: Colors.white),
                        onPressed: _handleCustomMarkerInput,
                        icon: const Icon(Icons.add_location),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        elevation: 0,
        onPressed: _userCurrentLocation,
        backgroundColor: Colors.blue,
        child: const Icon(
          Icons.my_location,
          size: 30,
          color: Colors.white,
        ),
      ),
    );
  }
}

