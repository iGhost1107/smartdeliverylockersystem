
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:last/Firebase/firestore.dart';

class HomePage extends StatefulWidget {
  final String customerPhone; // Pass this when navigating to HomePage

  const HomePage({super.key, required this.customerPhone});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final FireStoreService fireStoreService = FireStoreService();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("My Packages")),
      body: StreamBuilder<QuerySnapshot>(
        stream: fireStoreService.getPackagesByCustomer(widget.customerPhone),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          if (snapshot.hasData) {
            // Filter only the current user's packages
            List<DocumentSnapshot> packageList = snapshot.data!.docs;
            // List<DocumentSnapshot> packageList = snapshot.data!.docs.where((doc) {
            //   final data = doc.data() as Map<String, dynamic>;
            //   return data['customerPhone'] == widget.customerPhone;
            // }).toList();

            if (packageList.isEmpty) {
              return const Center(child: Text("You have no packages yet."));
            }

            return ListView.builder(
              itemCount: packageList.length,
              itemBuilder: (context, index) {
                final document = packageList[index];
                final data = document.data() as Map<String, dynamic>;

                final location = data['lockerLocation'] ?? 'Unknown';
                final size = data['size'] ?? 'Unknown';
                final slotId = data['slotId'];
                final createdAt = (data['createdAt'] as Timestamp?)?.toDate();

                return Card(
                  margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  child: ListTile(
                    title: Text('Locker: $location'),
                    subtitle: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Size: $size'),
                        Text('Slot ID: $slotId'),
                        if (createdAt != null)
                          Text('Created: ${createdAt.toLocal()}'),
                      ],
                    ),
                    trailing: IconButton(
                      icon: const Icon(Icons.download_done_rounded, color: Colors.green),
                      tooltip: "Receive",
                      onPressed: () async {
                        if (slotId != null) {
                          await fireStoreService.receivePackage(
                            document.id,
                            location,
                            slotId,
                          );

                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(content: Text("Your locker has opened. Please retrieve your item within 3 minutes")),
                          );
                        }
                      },
                    ),
                  ),
                );
              },
            );
          } else {
            return const Center(child: Text("Error loading packages."));
          }
        },
      ),
    );
  }
}

