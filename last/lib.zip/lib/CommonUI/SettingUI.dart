// import 'package:firebase_auth/firebase_auth.dart';
// import 'package:flutter/material.dart';
//
//
// class SettingUI extends StatefulWidget {
//   const SettingUI({super.key});
//
//   @override
//   State<SettingUI> createState() => _SettingUIState();
// }
//
// class _SettingUIState extends State<SettingUI> {
//
//   final user = FirebaseAuth.instance.currentUser!;
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       body: Center(child: Column(
//         mainAxisAlignment: MainAxisAlignment.center,
//         children: [
//           Text("Sign In with" + user.email!),
//           MaterialButton(
//               onPressed: () {
//                 FirebaseAuth.instance.signOut();
//               },
//               color: Colors.deepPurple[200],
//               child: Text("sign out"),
//           )
//         ],
//       )),
//     );
//   }
// }
