// import 'package:flutter/material.dart';
//
//
// class LockerPage extends StatelessWidget {
//   const LockerPage({super.key});
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       body: Center(
//         child: Text("Locker Page"),
//       ),
//     );
//   }
// }


import 'package:flutter/material.dart';

class LockerPage extends StatefulWidget {
  final String customerPhone;
  const LockerPage({Key? key, required this.customerPhone}) : super(key: key);

  @override
  State<LockerPage> createState() => _LockerPageState();
}

class _LockerPageState extends State<LockerPage> {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text('Locker - ${widget.customerPhone}'),
    );
  }
}
