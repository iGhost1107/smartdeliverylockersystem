// import 'package:flutter/material.dart';
// import 'package:flutter_map/flutter_map.dart';
// import 'package:flutter_map_location_marker/flutter_map_location_marker.dart';
// import 'package:latlong2/latlong.dart';
// import 'package:location/location.dart';
//
//
//
//
// class OpenstreetmapScreen extends StatefulWidget {
//   const OpenstreetmapScreen({super.key});
//
//   @override
//   State<OpenstreetmapScreen> createState() => _OpenstreetmapScreenState();
// }
//
// class _OpenstreetmapScreenState extends State<OpenstreetmapScreen> {
//   final MapController _mapController = MapController();
//   final Location _location = Location();
//   final TextEditingController _textEditingController = TextEditingController();
//   bool isLoading =true;
//   LatLng? _currentLocation;
//   LatLng? _destination;
//   List<LatLng> = _route = [];
//   Future<void> _initializationLocation() async {
//     if(!await _checktheRequestPermissions()) return;
//   }
//
//   Future<bool> _checktheRequestPermissions() {
//     bool serviceEnabled = await _location.serviceEnabled();
//     if(!serviceEnabled) {
//       serviceEnabled = await _location.requestService();
//       if(!serviceEnabled) return false;
//     }
//
//     PermissionStatus permissionGranted = await _location.hasPermission();
//     if(permissionGranted == PermissionStatus.denied) {
//       permissionGranted = await _location.requestPermission();
//       if (permissionGranted != PermissionStatus.granted) return false;
//     }
//     return true;
//   }
//
//
//
//
//
//
//   Future<void> _userCurrentLocation() async {
//     if(_currentLocation != null) {
//       _mapController.move(_currentLocation!, 15);
//     } else {
//       ScaffoldMessenger.of(context).showSnackBar(
//         const SnackBar(
//             content: Text("Current location not available")
//         )
//       );
//     }
//   }
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         foregroundColor: Colors.white,
//           title: const Text("Open Street Map"),
//             backgroundColor: Colors.blue,
//       ),
//       body: Stack(
//         children: [
//           FlutterMap(
//             mapController: _mapController,
//              options: MapOptions(
//                initialCenter: _currentLocation ??  const LatLng(21.0278, 105.8342),
//                initialZoom: 6,
//                minZoom: 0,
//                maxZoom: 18,
//              ),
//             children: [
//               TileLayer(
//                 urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
//                 // maxZoom: 19,
//               ),
//               CurrentLocationLayer(
//                 style: LocationMarkerStyle(
//                     marker: DefaultLocationMarker(
//                       child: Icon(
//                         Icons.location_pin,
//                         color: Colors.white,
//                       ),
//                     ),
//                     markerSize: Size(35, 35),
//                     markerDirection: MarkerDirection.heading,
//                 ),
//               )
//             ],)
//         ]
//       ),
//       floatingActionButton: FloatingActionButton(
//         elevation: 0,
//         onPressed: _userCurrentLocation,
//         backgroundColor: Colors.blue,
//         child: const Icon(
//           Icons.my_location, size: 30,
//           color: Colors.white,
//         ),
//       ),
//     );
//   }
// }
//
